from django.apps import AppConfig


class VisualsearchConfig(AppConfig):
    name = 'visualsearch'
